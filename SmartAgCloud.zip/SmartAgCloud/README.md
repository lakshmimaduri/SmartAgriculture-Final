# SmartAgCloud

Team project CMPE281
Hemaprasanthi Mutyala
Lakshmi Kameswari Maduri
Maahi Chatterjee
Wenyan He

~_~_~_~_~_~_~_~_ Log ~_~_~_~_~_~_~
Kindly keep the readme updated. We are only commiting on git to make sure that our project is working after it has been intergrated. Please everyone maintain 2 versions in your server. As discussed in the meeting on 19th March 2019, Cloud comes in when different componenets are on different laptops. So one version would contain the integrated version of the entire project and the other one will only have your components. Please make changes in the boiler plate.

03/18/2019 : Boiler plate created(MC)
