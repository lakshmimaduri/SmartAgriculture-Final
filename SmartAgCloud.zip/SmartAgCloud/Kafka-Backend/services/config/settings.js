"use strict";

//Dont TOUCH
module.exports = {
  secret: "Cmpe281_SmartAgCLoud Project"
};
