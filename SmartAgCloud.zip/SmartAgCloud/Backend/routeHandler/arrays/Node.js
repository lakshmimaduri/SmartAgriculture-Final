var Node = [
  {
    status: "on",
    x_coordinate: 56.45647,
    y_coordinate: 55.3458,
    farmerID: 1,
    //farmerID: {type: Schema.Types.ObjectId},
    humidity_sensor_vacancy: false,
    temperature_sensor_vacancy: false,
    moisture_sensor_vacancy: true,
    soil_nutrition_sensor_vacancy: false,
    ID: 1
  },
  {
    status: "on",
    x_coordinate: 67.235678,
    y_coordinate: 46.3354,
    farmerID: 1,
    //farmerID: {type: Schema.Types.ObjectId},
    humidity_sensor_vacancy: false,
    temperature_sensor_vacancy: false,
    moisture_sensor_vacancy: true,
    soil_nutrition_sensor_vacancy: false,
    ID: 2
  },
  {
    status: "on",
    x_coordinate: 14.8024,
    y_coordinate: 87.3567,
    farmerID: 1,
    //farmerID: {type: Schema.Types.ObjectId},
    humidity_sensor_vacancy: false,
    temperature_sensor_vacancy: false,
    moisture_sensor_vacancy: true,
    soil_nutrition_sensor_vacancy: false,
    ID: 3
  }
];

module.exports = Node;
