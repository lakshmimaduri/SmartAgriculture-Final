var Users = [
  {
    username: "user1",
    password: "pass1",
    email: "user1@smartag",
    userType: "farmer",
    img:
      "https://previews.123rf.com/images/hermandesign2015/hermandesign20151706/hermandesign2015170600062/79452046-cartoon-young-farmer-holding-rake.jpg"
  },
  {
    username: "user2",
    password: "pass2",
    email: "user2@smartag",
    userType: "farmer",
    img:
      "https://fscomps.fotosearch.com/compc/CSP/CSP747/cartoon-farmer-holding-a-rake-clipart__k25862630.jpg"
  },
  {
    username: "user3",
    password: "pass3",
    email: "user3@smartag",
    userType: "farmer",
    img:
      "https://c8.alamy.com/comp/E5K63B/farmer-and-rice-a-harvest-vector-illustration-cartoon-E5K63B.jpg"
  },
  {
    username: "user7",
    password: "pass7",
    email: "user7@smartag.com",
    userType: "iot_support",
    img:
      "https://previews.123rf.com/images/lawangdesign/lawangdesign1608/lawangdesign160800009/63132421-cartoon-young-farmer-holding-rake.jpg"
  },
  {
    username: "user10",
    password: "pass10",
    email: "user10@smartag.com",
    userType: "infrastructure_manager",
    img: "https://d2gg9evh47fn9z.cloudfront.net/800px_COLOURBOX24560947.jpg"
  }
];

module.exports = Users;
