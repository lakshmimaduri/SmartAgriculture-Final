//  //to be deleted. Just to give an example for how to design a mongoose schema

// var mongoose = require("mongoose");

// var IOT_Dashboard = mongoose.model("IOT", {
//   list_of_farmers:[{ firstName: {
//     type: String,
//     default: "firstname"
//   },
//   lastName: {
//     type: String,
//     default: "lasttname"
//   },
//   type: {
//     type: String,
//     default: "traveller/owner"
//   },
//   phone: {
//     type: String,
//     default: "xxx-xxx-xxxx"
//   }}],
//   list_of_sensors:[{
//   	name:{type:String},
//   	connectivityStatus: {type:String},
//   	clusterID:{Object.Types.ID}
//   }],
//   list_of_nodes:[{
//   	name:{type:String},
//   	connectivityStatus: {type:String},
//   	clusterID:{Object.Types.ID}
//   }],
//   list_of_clusters:[
//   	name: {type: String},
//   	connectivityStatus:{type:String}
//   ]

// });

// module.exports = { IOT_Dashboard };

