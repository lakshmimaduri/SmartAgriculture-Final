"use strict";

//NO change. DON'T TOUCH
module.exports = {
  secret: "Passphrase for encryption should be 45-50 char long"
};
