[{
    username: "user1",
    password: "pass1" ,
    email: "user1@smartag",
    userType: "farmer",
    firstName: "user1",
    lastName: "lastname1",
    city: "city1",
    state: "state1",
    county: "county1"
},
{
    
}]