[{
    sensorType: "humidity sensor",
    status: "on",
    x_coordinate: 2.13,
    y_coordinate: 4.50,
    data: {
        timestamp: ISODate("2018-06-30T00:00:01Z"),
        type: "humidity or temperature or blah",
        value: 3.125
      },
},{
    sensorType: "humidity sensor",
    status: "on",
    x_coordinate: 2.13,
    y_coordinate: 4.50,
    data: {
        timestamp: ISODate("2018-06-30T00:00:01Z"),
        type: "humidity or temperature or blah",
        value: 3.125
}]

